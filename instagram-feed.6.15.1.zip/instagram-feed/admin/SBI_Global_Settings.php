<?php

/**
 * The Settings Page
 *
 * @since 6.0
 */

namespace InstagramFeed\Admin;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

use DateTime;
use InstagramFeed\Abilities\SBI_Pro_Upsell;
use InstagramFeed\Builder\SBI_Db;
use InstagramFeed\Builder\SBI_Feed_Builder;
use InstagramFeed\Builder\SBI_Feed_Saver_Manager;
use InstagramFeed\Builder\SBI_Source;
use InstagramFeed\Helpers\Util;
use InstagramFeed\SBI_HTTP_Request;
use InstagramFeed\SBI_Response;
use InstagramFeed\SBI_View;
use SB_Instagram_Cache;
use SB_Instagram_Cron_Updater;
use SB_Instagram_Feed_Locator;
use SB_Instagram_GDPR_Integrations;
use function json_decode;
use function sbi_is_pro_version;
use function stripslashes;
use InstagramFeed\UsageTracking\Config as SmashTrackingConfig;

class SBI_Global_Settings
{
	// use SBI_Settings;
	/**
	 * Admin menu page slug.
	 *
	 * @since 6.0
	 *
	 * @var string
	 */
	const SLUG = 'sbi-settings';

	/**
	 * Initializing the class
	 *
	 * @since 6.0
	 */
	public function __construct()
	{
		$this->init();
	}

	/**
	 * Determining if the user is viewing the our page, if so, party on.
	 *
	 * @since 6.0
	 */
	public function init()
	{
		if (!is_admin()) {
			return;
		}

		add_action('admin_menu', [$this, 'register_menu']);
		add_action('in_admin_header', [$this, 'maybe_remove_admin_footer']);

		add_action('wp_ajax_sbi_save_settings', [$this, 'sbi_save_settings']);
		add_action('wp_ajax_sbi_activate_license', [$this, 'sbi_activate_license']);
		add_action('wp_ajax_sbi_deactivate_license', [$this, 'sbi_deactivate_license']);
		add_action('wp_ajax_sbi_test_connection', [$this, 'sbi_test_connection']);
		add_action('wp_ajax_sbi_recheck_connection', [$this, 'sbi_recheck_connection']);
		add_action('wp_ajax_sbi_import_settings_json', [$this, 'sbi_import_settings_json']);
		add_action('wp_ajax_sbi_export_settings_json', [$this, 'sbi_export_settings_json']);
		add_action('wp_ajax_sbi_clear_cache', [$this, 'sbi_clear_cache']);
		add_action('wp_ajax_sbi_clear_image_resize_cache', [$this, 'sbi_clear_image_resize_cache']);
		add_action('wp_ajax_sbi_clear_error_log', [$this, 'sbi_clear_error_log']);
		add_action('wp_ajax_sbi_retry_db', [$this, 'sbi_retry_db']);
		add_action('wp_ajax_sbi_dpa_reset', [$this, 'sbi_dpa_reset']);
	}

	/**
	 * SBI Save Settings
	 *
	 * This will save the data fron the settings page
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_save_settings()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}
		$data = $_POST;
		$model = isset($data['model']) ? $data['model'] : null;

		// return if the model is null
		if (null === $model) {
			return;
		}

		// get the sbi license key and extensions license key
		$sbi_license_key = sanitize_text_field($_POST['sbi_license_key']);

		// Only update the sbi_license_key value when it's inactive
		if (get_option('sbi_license_status') == 'inactive') {
			if (empty($sbi_license_key) || strlen($sbi_license_key) < 1) {
				delete_option('sbi_license_key');
				delete_option('sbi_license_data');
				delete_option('sbi_license_status');
			} else {
				update_option('sbi_license_key', $sbi_license_key);
			}
		} else {
			$license_key = sanitize_key(trim(get_option('sbi_license_key', '')));

			if (empty($sbi_license_key) && !empty($license_key)) {
				$sbi_license_data = $this->get_license_data($license_key, 'deactivate_license', SBI_PLUGIN_NAME);

				delete_option('sbi_license_key');
				delete_option('sbi_license_data');
				delete_option('sbi_license_status');
			}
		}

		$model = (array)json_decode(stripslashes($model));

		$general = (array)$model['general'];
		$feeds = (array)$model['feeds'];
		$advanced = (array)$model['advanced'];

		// Get the values and sanitize
		$sbi_settings = get_option('sb_instagram_settings', array());

		/**
		 * General Tab
		 */
		$sbi_settings['sb_instagram_preserve_settings'] = $general['preserveSettings'];

		/**
		 * Feeds Tab
		 */
		if (current_user_can('unfiltered_html')) {
			$sbi_settings['sb_instagram_custom_css'] = $feeds['customCSS'];
			$sbi_settings['sb_instagram_custom_js'] = $feeds['customJS'];
		}

		$sbi_settings['gdpr'] = sanitize_text_field($feeds['gdpr']);
		$sbi_settings['sbi_cache_cron_interval'] = sanitize_text_field($feeds['cronInterval']);
		$sbi_settings['sbi_cache_cron_time'] = sanitize_text_field($feeds['cronTime']);
		$sbi_settings['sbi_cache_cron_am_pm'] = sanitize_text_field($feeds['cronAmPm']);

		/**
		 * Advanced Tab
		 */
		$sbi_settings['sb_instagram_ajax_theme'] = sanitize_text_field($advanced['sbi_ajax']);
		$sbi_settings['sb_instagram_disable_resize'] = !(bool)$advanced['sbi_enable_resize'];
		$sbi_settings['image_format'] = sanitize_text_field($advanced['image_format']);
		$sbi_settings['sb_ajax_initial'] = (bool)$advanced['sb_ajax_initial'];
		$sbi_settings['enqueue_js_in_head'] = (bool)$advanced['sbi_enqueue_js_in_head'];
		$sbi_settings['enqueue_css_in_shortcode'] = (bool)$advanced['sbi_enqueue_css_in_shortcode'];
		$sbi_settings['disable_js_image_loading'] = !(bool)$advanced['sbi_enable_js_image_loading'];
		$sbi_settings['disable_admin_notice'] = !(bool)$advanced['enable_admin_notice'];
		$sbi_settings['enable_email_report'] = (bool)$advanced['enable_email_report'];
		$sbi_settings['enqueue_legacy_css'] = (bool)$advanced['enqueue_legacy_css'];
		// AI write-access toggle (AgDR-9005/AgDR-9004): this single AJAX handler
		// always posts the FULL model (general + feeds + advanced together), so
		// unlike a genuinely partial per-tab save, !empty() here is fail-closed
		// without risk of resetting an enabled toggle from an unrelated tab —
		// a missing/false key on this save legitimately means "off". Never
		// (bool)$advanced['sbi_ai_write_enabled'] directly: that idiom warns on a
		// missing key instead of failing closed.
		$sbi_settings['sb_instagram_ai_write_enabled'] = $this->reconcile_ai_write_toggle($advanced, !empty($sbi_settings['sb_instagram_ai_write_enabled']));

		$sbi_settings['email_notification'] = sanitize_text_field($advanced['email_notification']);
		$sbi_settings['email_notification_addresses'] = sanitize_text_field($advanced['email_notification_addresses']);

		if ( isset( $advanced['usage_tracking'] ) ) {
			$tracking_enabled = (bool) $advanced['usage_tracking'];
			$usage_tracking   = get_option(
				'sbi_usage_tracking',
				array(
					'enabled'   => SmashTrackingConfig::DEFAULT_ENABLED,
					'last_send' => 0,
				)
			);
			$last_send        = is_array( $usage_tracking ) && isset( $usage_tracking['last_send'] ) ? $usage_tracking['last_send'] : 0;
			update_option(
				'sbi_usage_tracking',
				array(
					'enabled'   => $tracking_enabled,
					'last_send' => $last_send,
				),
				false
			);
			if ( ! $tracking_enabled ) {
				wp_clear_scheduled_hook( SmashTrackingConfig::CRON_HOOK );
			}
		}

		/**
		 * Debug Tab — consent toggles.
		 *
		 * Routed through SBI_Consent::update() so cron reconciliation and the
		 * 3-state notification source switch stay consistent. Pass null for
		 * $dismiss_modal so the re-prompt-modal state is not affected by a
		 * Settings save. The flags are stored as top-level wp_options, NOT in
		 * sb_instagram_settings, so we do not add them to $sbi_settings.
		 */
		if ( isset( $model['debug'] ) && class_exists( 'SBI_Consent' ) ) {
			$debug = (array) $model['debug'];
			\SBI_Consent::update(
				! empty( $debug['sbc_data_sharing_consent'] ),
				! empty( $debug['sbc_in_plugin_notifications'] ),
				null
			);
		}

		// Update the sbi_style_settings option that contains data for translation and advanced tabs
		update_option('sb_instagram_settings', $sbi_settings);

		// clear cron caches. Not sbi_clear_cache(): it sends its own response and
		// exits, so the response below (with aiWriteEnabled) would never go out.
		$this->reset_caches_and_cron();

		$response = new SBI_Response(true, array(
			'cronNextCheck' => $this->get_cron_next_check(),
			// The stored toggle, so the page can resync after a save (a refused stale-tab ON, or a flip back on in the same tab).
			'aiWriteEnabled' => !empty($sbi_settings['sb_instagram_ai_write_enabled']),
		));
		$response->send();
	}

	/**
	 * SBI Get License Data from our license API
	 *
	 * @param string $license_key
	 * @param string $license_action
	 *
	 * @return void|array $sbi_license_data
	 * @since 6.0
	 */
	public function get_license_data($license_key, $license_action = 'check_license', $item_name = SBI_PLUGIN_NAME)
	{
		$sbi_api_params = array(
			'edd_action' => $license_action,
			'license' => $license_key,
			'item_name' => urlencode($item_name) // the name of our product in EDD
		);
		$url = add_query_arg($sbi_api_params, SBI_STORE_URL);
		$args = array(
			'timeout' => 60,
			'sslverify' => false
		);
		// Make the remote API request
		$request = SBI_HTTP_Request::request('GET', $url, $args);
		if (SBI_HTTP_Request::is_error($request)) {
			return;
		}
		$sbi_license_data = (array)SBI_HTTP_Request::data($request);
		return $sbi_license_data;
	}

	/**
	 * SBI Clear Cache
	 *
	 * @since 6.0
	 */
	public function sbi_clear_cache()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}

		$this->reset_caches_and_cron();

		$response = new SBI_Response(true, array(
			'cronNextCheck' => $this->get_cron_next_check()
		));
		$response->send();
	}

	/**
	 * Clear the feed caches and restart the cache cron, without sending a response.
	 *
	 * Shared by the Clear Cache AJAX handler and the Settings save, which sends
	 * its own response afterwards.
	 */
	private function reset_caches_and_cron()
	{
		// Get the updated cron schedule interval and time values
		$sbi_settings = get_option('sb_instagram_settings', array());

		$sbi_cache_cron_interval = $sbi_settings['sbi_cache_cron_interval'];
		$sbi_cache_cron_time = $sbi_settings['sbi_cache_cron_time'];
		$sbi_cache_cron_am_pm = $sbi_settings['sbi_cache_cron_am_pm'];

		// Clear the stored caches in the database
		$this->clear_stored_caches();

		delete_option('sbi_cron_report');
		SB_Instagram_Cron_Updater::start_cron_job($sbi_cache_cron_interval, $sbi_cache_cron_time, $sbi_cache_cron_am_pm);

		global $sb_instagram_posts_manager;
		$sb_instagram_posts_manager->add_action_log('Saved settings on the configure tab.');
		$sb_instagram_posts_manager->clear_api_request_delays();
	}

	/**
	 * Clear the stored caches from the database and from other caching plugins
	 *
	 * @since 6.0
	 */
	public function clear_stored_caches()
	{
		sbi_clear_all_feed_caches();
	}

	/**
	 * SBI Get cron next check time
	 *
	 * @return string $output
	 * @since 6.0
	 */
	public function get_cron_next_check()
	{
		$output = '';

		if (wp_next_scheduled('sbi_feed_update')) {
			$time_format = get_option('time_format');
			if (!$time_format) {
				$time_format = 'g:i a';
			}
			$schedule = wp_get_schedule('sbi_feed_update');
			if ($schedule == '30mins') {
				$schedule = __('every 30 minutes', 'instagram-feed');
			}
			if ($schedule == 'twicedaily') {
				$schedule = __('every 12 hours', 'instagram-feed');
			}
			$sbi_next_cron_event = wp_next_scheduled('sbi_feed_update');
			$output = '<b>' . __('Next check', 'instagram-feed') . ': ' . date($time_format, $sbi_next_cron_event + sbi_get_utc_offset()) . ' (' . $schedule . ')</b> - ' . __('Note: Clicking "Clear All Caches" will reset this schedule.', 'instagram-feed');
		} else {
			$output = __('Nothing currently scheduled', 'instagram-feed');
		}

		return $output;
	}

	/**
	 * SBI Activate License Key
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_activate_license()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}
		// do the form validation to check if license_key is not empty
		if (empty($_POST['license_key'])) {
			$response = new SBI_Response(false, array(
				'message' => __('License key required!', 'instagram-feed'),
			));
			$response->send();
		}
		$license_key = sanitize_key($_POST['license_key']);
		// make the remote api call and get license data
		$sbi_license_data = $this->get_license_data($license_key, 'activate_license', SBI_PLUGIN_NAME);

		// update the license data
		if (!empty($sbi_license_data)) {
			update_option('sbi_license_data', $sbi_license_data);
		}
		// update the licnese key only when the license status is activated
		update_option('sbi_license_key', $license_key);
		// update the license status
		update_option('sbi_license_status', $sbi_license_data['license']);

		// Check if there is any error in the license key then handle it
		$sbi_license_data = $this->get_license_error_message($sbi_license_data);

		// Send ajax response back to client end
		$data = array(
			'licenseStatus' => $sbi_license_data['license'],
			'licenseData' => $sbi_license_data
		);
		$response = new SBI_Response(true, $data);
		$response->send();
	}

	/**
	 * Get license error message depending on license status
	 *
	 * @param array $sbi_license_data
	 *
	 * @return array $sbi_license_data
	 * @since 6.0
	 */
	public function get_license_error_message($sbi_license_data)
	{
		global $sbi_download_id;

		$license_key = null;
		if (get_option('sbi_license_key')) {
			$license_key = sanitize_key(get_option('sbi_license_key'));
		}

		$upgrade_url = sprintf('https://smashballoon.com/instagram-feed/instagram-lite-upgrade/?license_key=%s&upgrade=true&utm_campaign=instagram-free&utm_source=settings&utm_medium=upgrade-license', $license_key);
		$renew_url = sprintf('https://smashballoon.com/checkout/?license_key=%s&download_id=%s&utm_campaign=instagram-free&utm_source=settings&utm_medium=upgrade-license&utm_content=renew-license', $license_key, sanitize_key($sbi_download_id));
		$learn_more_url = 'https://smashballoon.com/doc/my-license-key-wont-activate/?utm_campaign=instagram-free&utm_source=settings&utm_medium=license&utm_content=learn-more';

		// Check if the license key reached max site installations
		if (isset($sbi_license_data['error']) && 'no_activations_left' === $sbi_license_data['error']) {
			$sbi_license_data['errorMsg'] = sprintf(__('You have reached the maximum number of sites available in your plan %s', 'instagram-feed'), '(' . (int)$sbi_license_data['site_count'] . '/' . (int)$sbi_license_data['max_sites'] . ')');
			$sbi_license_data['errorMsg'] .= ' ' . sprintf(__('%sLearn more about%s it or %supgrade your plan%s', 'instagram-feed'), '<a href="' . esc_url($learn_more_url) . '" target="_blank" rel="noopener">', '</a>', '<a href="' . esc_url($upgrade_url) . '" rel="noopener" target="_blank">', '</a>');
		}
		// Check if the license key has expired
		if (
			(isset($sbi_license_data['license']) && 'expired' === $sbi_license_data['license']) ||
			(isset($sbi_license_data['error']) && 'expired' === $sbi_license_data['error'])
		) {
			$sbi_license_data['error'] = true;
			$expired_date = new DateTime($sbi_license_data['expires']);
			$expired_date = $expired_date->format('F d, Y');
			$sbi_license_data['errorMsg'] = sprintf(
				'%s %s. %s <a href="%s" target="_blank">%s</a>',
				__('The license expired on ', 'instagram-feed'),
				$expired_date,
				__('Please renew it and try again.', 'instagram-feed'),
				$renew_url,
				__('Renew', 'instagram-feed')
			);
		}
		return $sbi_license_data;
	}

	/**
	 * SBI Deactivate License Key
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_deactivate_license()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}
		$license_key = sanitize_key(trim(get_option('sbi_license_key', '')));
		$sbi_license_data = $this->get_license_data($license_key, 'deactivate_license', SBI_PLUGIN_NAME);
		// update the license data
		if (!empty($sbi_license_data)) {
			update_option('sbi_license_data', $sbi_license_data);
		}
		if (!$sbi_license_data['success']) {
			$response = new SBI_Response(false, array());
			$response->send();
		}
		// remove the license keys and update license key status
		if ($sbi_license_data['license'] == 'deactivated') {
			update_option('sbi_license_status', 'inactive');
			$data = array(
				'licenseStatus' => 'inactive'
			);
			$response = new SBI_Response(true, $data);
			$response->send();
		}
	}

	/**
	 * SBI Test Connection
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_test_connection()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}
		$license_key = sanitize_key(get_option('sbi_license_key', ''));
		$sbi_api_params = array(
			'edd_action' => 'check_license',
			'license' => $license_key,
			'item_name' => urlencode(SBI_PLUGIN_NAME) // the name of our product in EDD
		);
		$url = add_query_arg($sbi_api_params, SBI_STORE_URL);
		$args = array(
			'timeout' => 60,
			'sslverify' => false
		);
		// Make the remote API request
		$request = SBI_HTTP_Request::request('GET', $url, $args);
		if (SBI_HTTP_Request::is_error($request)) {
			$message = '';
			foreach ($request->errors as $key => $error) {
				$message .= esc_html($key) . ' - ' . esc_html($error[0]);
			}
			$response = new SBI_Response(false, array(
				'hasError' => true,
				'error' => $message
			));
			$response->send();
		}

		$response = new SBI_Response(true, array(
			'hasError' => false
		));
		$response->send();
	}

	/**
	 * SBI Re-Check License
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_recheck_connection()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}
		// Do the form validation
		$license_key = isset($_POST['license_key']) ? sanitize_key($_POST['license_key']) : '';
		$item_name = isset($_POST['item_name']) ? sanitize_text_field($_POST['item_name']) : '';
		$option_name = isset($_POST['option_name']) ? sanitize_text_field($_POST['option_name']) : '';
		if (empty($license_key) || empty($item_name)) {
			$response = new SBI_Response(false, array());
			$response->send();
		}

		// make the remote license check API call
		$sbi_license_data = $this->get_license_data($license_key, 'check_license', $item_name);

		// update options data
		$license_changed = $this->update_recheck_license_data($sbi_license_data, $item_name, $option_name);

		// send AJAX response back
		$response = new SBI_Response(true, array(
			'license' => $sbi_license_data['license'],
			'licenseChanged' => $license_changed
		));
		$response->send();
	}

	/**
	 * Update License Data
	 *
	 * @param array  $license_data
	 * @param string $item_name
	 * @param string $option_name
	 *
	 * @return bool $license_changed
	 * @since 6.0
	 */
	public function update_recheck_license_data($license_data, $item_name, $option_name)
	{
		$license_changed = false;
		// if we are updating plugin's license data
		if (SBI_PLUGIN_NAME == $item_name) {
			// compare the old stored license status with new license status
			if (get_option('sbi_license_status') != $license_data['license']) {
				$license_changed = true;
			}
			update_option('sbi_license_data', $license_data);
			update_option('sbi_license_status', $license_data['license']);
		}

		// If we are updating extensions license data
		if (SBI_PLUGIN_NAME != $item_name) {
			// compare the old stored license status with new license status
			if (get_option('sbi_license_status_' . $option_name) != $license_data['license']) {
				$license_changed = true;
			}
			update_option('sbi_license_status_' . $option_name, $license_data['license']);
		}
		// if we are updating extensions license data and it's not valid
		// then remote the extensions license status
		if (SBI_PLUGIN_NAME != $item_name && 'valid' != $license_data['license']) {
			delete_option('sbi_license_status_' . $option_name);
		}

		return $license_changed;
	}

	/**
	 * SBI Import Feed Settings JSON
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_import_settings_json()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}

		$filename = $_FILES['file']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		if ('json' !== $ext) {
			$response = new SBI_Response(false, []);
			$response->send();
		}
		$imported_settings = file_get_contents($_FILES["file"]["tmp_name"]);
		// check if the file is empty
		if (empty($imported_settings)) {
			$response = new SBI_Response(false, []);
			$response->send();
		}
		$feed_return = SBI_Feed_Saver_Manager::import_feed($imported_settings);
		// check if there's error while importing
		if (!$feed_return['success']) {
			$response = new SBI_Response(false, []);
			$response->send();
		}
		// Once new feed has imported lets export all the feeds to update in front end
		$exported_feeds = SBI_Db::feeds_query();
		$feeds = array();
		foreach ($exported_feeds as $feed_id => $feed) {
			$feeds[] = array(
				'id' => $feed['id'],
				'name' => $feed['feed_name']
			);
		}

		$response = new SBI_Response(true, array(
			'feeds' => $feeds
		));
		$response->send();
	}

	/**
	 * SBI Export Feed Settings JSON
	 *
	 * @return void
	 * @since 6.0
	 */
	public function sbi_export_settings_json()
	{
		if (!check_ajax_referer('sbi-admin', 'nonce', false)) {
			wp_send_json_error();
		}

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error(); // This auto-dies.
		}

		if (!isset($_GET['feed_id'])) {
			return;
		}
		$feed_id = filter_var($_GET['feed_id'], FILTER_SANITIZE_NUMBER_INT);
		$feed = SBI_Feed_Saver_Manager::get_export_json($feed_id);
		$feed_info = SBI_Db::feeds_query(array('id' => $feed_id));
		$feed_name = strtolower($feed_info[0]['feed_name']);
		$filename = 'sbi-feed-' . $feed_name . '.json';
		// create a new empty file in the php memory
		$file = fopen('php://memory', 'w');
		fwrite($file, $feed);
		fseek($file, 0);
		header('Content-type: application/json');
		header('Content-disposition: attachment; filename = "' . $filename . '";');
		fpassthru($file);
		exit;
	}

	/**
	 * SBI Clear Image Resize Cache
	 *
	 * @since 6.0
	 */
	public function sbi_clear_image_resize_cache()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}

		global $sb_instagram_posts_manager;
		$sb_instagram_posts_manager->delete_all_sbi_instagram_posts();
		delete_option('sbi_top_api_calls');

		$sb_instagram_posts_manager->add_action_log('Reset resizing tables.');
		$this->clear_stored_caches();

		$response = new SBI_Response(true, []);
		$response->send();
	}

	/**
	 * SBI CLear Error Log
	 *
	 * @since 6.0
	 */
	public function sbi_clear_error_log()
	{
		// Security Checks
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}

		global $sb_instagram_posts_manager;
		$sb_instagram_posts_manager->remove_all_errors();

		global $sbi_notices;
		$sbi_notices->remove_notice('critical_error');
		$sbi_notices->remove_notice('database_error');

		$user_id = get_current_user_id();
		update_user_meta($user_id, 'sbi_ignore_new_user_sale_notice', 'always');
		update_user_meta($user_id, 'sb_notice_discount_dismissed', true);
		$sbi_notices->remove_notice('discount');

		$sbi_statuses_option = get_option('sbi_statuses', array());
		update_option('sbi_rating_notice', 'dismissed', false);
		$sbi_statuses_option['rating_notice_dismissed'] = sbi_get_current_time();
		update_option('sbi_statuses', $sbi_statuses_option, false);

		// remove the rating notice step 1 and step 2 from global notices
		$sbi_notices->remove_notice('review_step_1');
		$sbi_notices->remove_notice('review_step_2');
		$sbi_notices->remove_notice('review_step_1_all_pages');
		$sbi_notices->remove_notice('review_step_2_all_pages');

		wp_send_json_success();
	}

	/**
	 * SBI CLear Error Log
	 *
	 * @since 6.0
	 */
	public function sbi_retry_db()
	{
		// Security Checks
		check_ajax_referer('sbi_nonce', 'sbi_nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}
		sbi_create_database_table();
		SB_Instagram_Feed_Locator::create_table();
		SBI_Db::create_tables();

		global $wpdb;
		$table_name = $wpdb->prefix . SBI_INSTAGRAM_POSTS_TYPE;

		if ($wpdb->get_var("show tables like '$table_name'") !== $table_name) {
			wp_send_json_error(array('message' => '<div style="margin-top: 10px;">' . esc_html__('Unsuccessful. Try visiting our website.', 'instagram-feed') . '</div>'));
		}

		global $sbi_notices;
		global $sb_instagram_posts_manager;

		$sbi_notices->remove_notice('database_create');
		$sbi_notices->remove_notice('database_error');
		$sb_instagram_posts_manager->remove_error('database_error');

		wp_send_json_success(array('message' => '<div style="margin-top: 10px;">' . esc_html__('Success! Try creating a feed and connecting a source.', 'instagram-feed') . '</div>'));
	}

	/**
	 * SBI Clear Image Resize Cache
	 *
	 * @since 6.0
	 */
	public function sbi_dpa_reset()
	{
		check_ajax_referer('sbi-admin', 'nonce');

		if (!sbi_current_user_can('manage_instagram_feed_options')) {
			wp_send_json_error();
		}

		sbi_delete_all_platform_data();

		$this->clear_stored_caches();

		$response = new SBI_Response(true, []);
		$response->send();
	}

	/**
	 * Conditionally remove admin footer on plugin pages only.
	 *
	 * @since 6.11
	 */
	public function maybe_remove_admin_footer()
	{
		if (Util::isIFPage()) {
			add_filter('admin_footer_text', [$this, 'remove_admin_footer_text']);
			add_filter('update_footer', [$this, 'remove_admin_footer_text'], 11);
		}
	}

	/**
	 * Remove admin footer message
	 *
	 * @return string
	 * @since 6.0
	 */
	public function remove_admin_footer_text()
	{
		return '';
	}

	/**
	 * Register Menu.
	 *
	 * @since 6.0
	 */
	public function register_menu()
	{

		$cap = current_user_can('manage_custom_instagram_feed_options') ? 'manage_custom_instagram_feed_options' : 'manage_options';
		$cap = apply_filters('sbi_settings_pages_capability', $cap);

		global $sb_instagram_posts_manager;
		$notice = '';
		if ($sb_instagram_posts_manager->are_critical_errors()) {
			$notice = ' <span class="update-plugins sbi-error-alert sbi-notice-alert"><span>!</span></span>';
		}

		$global_settings = add_submenu_page(
			'sb-instagram-feed',
			__('Settings', 'instagram-feed'),
			__('Settings ' . $notice, 'instagram-feed'),
			$cap,
			'sbi-settings',
			[$this, 'global_settings'],
			1
		);
		add_action('load-' . $global_settings, [$this, 'builder_enqueue_admin_scripts']);
	}

	/**
	 * Enqueue Builder CSS & Script.
	 *
	 * Loads only for builder pages
	 *
	 * @since 6.0
	 */
	public function builder_enqueue_admin_scripts()
	{
		if (!get_current_screen()) {
			return;
		}
		$screen = get_current_screen();
		if (!'instagram-feed_page_sbi-settings' === $screen->id) {
			return;
		}
		$sbi_status = 'inactive';

		global $wp_version;

		$model = $this->get_settings_data();
		$exported_feeds = SBI_Db::feeds_query();
		$feeds = array();
		foreach ($exported_feeds as $feed_id => $feed) {
			$feeds[] = array(
				'id' => $feed['id'],
				'name' => $feed['feed_name']
			);
		}
		$licenseErrorMsg = null;
		$license_key = sanitize_key(trim(get_option('sbi_license_key', '')));
		if ($license_key) {
			$license_last_check = get_option('sbi_license_last_check_timestamp');
			$date = time() - (DAY_IN_SECONDS * 90);
			if ($date > $license_last_check) {
				// make the remote api call and get license data
				$sbi_license_data = $this->get_license_data($license_key);
				if (!empty($sbi_license_data)) {
					update_option('sbi_license_data', $sbi_license_data);
				}
				update_option('sbi_license_last_check_timestamp', time());
			} else {
				$sbi_license_data = get_option('sbi_license_data');
			}
			// update the license data with proper error messages when necessary
			$sbi_license_data = $this->get_license_error_message($sbi_license_data);
			$sbi_status = !empty($sbi_license_data['license']) ? $sbi_license_data['license'] : false;
			$licenseErrorMsg = (isset($sbi_license_data['error']) && isset($sbi_license_data['errorMsg'])) ? $sbi_license_data['errorMsg'] : null;
		}

		$current_user_id = get_current_user_id();
		$get_sb_active_plugins_info = Util::get_sb_active_plugins_info();

		wp_enqueue_style(
			'settings-style',
			SBI_PLUGIN_URL . 'admin/assets/css/settings.css',
			array( 'common' ),
			SBIVER
		);

		SBI_Feed_Builder::global_enqueue_ressources_scripts(true);

		wp_register_script('feed-builder-svgs', SBI_PLUGIN_URL . 'assets/svgs/svgs.js');

		wp_enqueue_script(
			'settings-app',
			SBI_PLUGIN_URL . 'admin/assets/js/settings.js',
			array('feed-builder-svgs'),
			SBIVER,
			true
		);
		// SMASH-1378 A11Y-004: focus trap for popups declared as role="dialog".
		// Mirrors SBI_Feed_Builder::builder_enqueue_admin_scripts so the Delete
		// Source confirm dialog on the Settings page traps focus the same way.
		wp_enqueue_script(
			'sbi-popup-focus-trap',
			SBI_PLUGIN_URL . 'admin/builder/assets/js/popup-focus-trap.js',
			array(),
			SBIVER,
			true
		);

		$license_key = null;
		if (get_option('sbi_license_key')) {
			$license_key = sanitize_key(get_option('sbi_license_key'));
		}

		$has_license_error = false;
		if (
			(isset($sbi_license_data['license']) && 'expired' === $sbi_license_data['license']) ||
			(isset($sbi_license_data['error']) && ($sbi_license_data['error'] || 'expired' == $sbi_license_data['error']))
		) {
			$has_license_error = true;
		}

		$upgrade_url = sprintf('https://smashballoon.com/instagram-feed/instagram-lite-upgrade/?license_key=%s&upgrade=true&utm_campaign=instagram-free&utm_source=settings&utm_medium=upgrade-license', $license_key);
		$footer_upgrade_url = 'https://smashballoon.com/instagram-feed/instagram-lite-upgrade/?utm_campaign=instagram-free&utm_source=settings&utm_medium=footer-banner&utm_content=Try Demo';
		$usage_tracking_url = 'https://smashballoon.com/instagram-feed/usage-tracking/?utm_campaign=instagram-free&utm_source=settings&utm_medium=docs';
		$feed_issue_email_url = 'https://smashballoon.com/doc/email-report-is-not-in-my-inbox/?instagram&utm_campaign=instagram-free&utm_source=settings&utm_medium=docs';

		// SMASH-1245 — Settings/Debug consent links route through the shared
		// Consent package (sb-common owns the canonical URLs + per-surface UTM
		// tags: utm_source=settings-consent, dynamic {plugin}-free campaign).
		// Empty when the package is absent rather than duplicating the URLs here.
		$sbi_consent_permissions_url = '';
		$sbi_consent_terms_url       = '';
		$sbi_consent_privacy_url     = '';
		if ( class_exists( '\InstagramFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager' ) ) {
			$sbi_consent_permissions_url = \InstagramFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager::link_url( 'settings', 'permissions', 'instagram' );
			$sbi_consent_terms_url       = \InstagramFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager::link_url( 'settings', 'terms', 'instagram' );
			$sbi_consent_privacy_url     = \InstagramFeed\Vendor\Smashballoon\Framework\Packages\Consent\ConsentManager::link_url( 'settings', 'privacy', 'instagram' );
		}

		$sources_list = SBI_Feed_Builder::get_source_list();

		// Extract only license keys and build array for extensions license keys

		$wpvibe             = $this->get_wpvibe_status();
		$wpvibe_org_url     = 'https://wordpress.org/plugins/vibe-ai/';
		// Minimal allowlist for the AI Agents card copy below: these strings reach
		// the localize-data array and are rendered with v-html in
		// admin/views/settings/tab/general.php, so they must be sanitized before
		// they're placed into $sbi_settings, not trusted as literal markup.
		$ai_agents_allowed_html = array(
			'br'     => array(),
			'strong' => array(),
			'a'      => array(
				'href'   => array(),
				'target' => array(),
				'rel'    => array(),
			),
		);
		/* translators: %s: URL to the WPVibe plugin on WordPress.org */
		$wpvibe_description = wp_kses(
			sprintf(__('Manage Instagram Feed from your favorite AI agent.<br>Works through <a href="%s" target="_blank" rel="noopener">WPVibe</a>, a free plugin you install once.', 'instagram-feed'), esc_url($wpvibe_org_url)), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
			$ai_agents_allowed_html
		);

		$sbi_settings = array(
			'admin_url' => admin_url(),
			'ajax_handler' => admin_url('admin-ajax.php'),
			'nonce' => wp_create_nonce('sbi-admin'),
			'supportPageUrl' => admin_url('admin.php?page=sbi-support'),
			'builderUrl' => admin_url('admin.php?page=sbi-feed-builder'),
			'links' => $this->get_links_with_utm(),
			'pluginItemName' => SBI_PLUGIN_NAME,
			'licenseType' => 'free',
			'licenseKey' => $license_key,
			'licenseStatus' => $sbi_status,
			'licenseErrorMsg' => $licenseErrorMsg,
			'extensionsLicense' => array(),
			'extensionsLicenseKey' => array(),
			'hasError' => $has_license_error,
			'upgradeUrl' => $upgrade_url,
			'footerUpgradeUrl' => $footer_upgrade_url,
			'isDevSite' => SBI_Upgrader::is_dev_url(home_url()),
			'model' => $model,
			'feeds' => $feeds,
			'sources' => $sources_list,
			'socialWallLinks' => SBI_Feed_Builder::get_social_wall_links(),
			'socialWallActivated' => is_plugin_active('social-wall/social-wall.php'),
			'genericText' => SBI_Feed_Builder::get_generic_text(),
			'legacyCSSSettings' => Util::sbi_show_legacy_css_settings(),
			'generalTab' => array(
				'licenseBox' => array(
					'title' => __('License Key', 'instagram-feed'),
					'description' => __('Your license key provides access to updates and support', 'instagram-feed'),
					'activeText' => __('Your <b>Instagram Feed Pro</b> license is Active!', 'instagram-feed'),
					'inactiveText' => __('Your <b>Instagram Feed Pro</b> license is Inactive!', 'instagram-feed'),
					'freeText' => __('Already purchased? Simply enter your license key below to activate Instagram Feed Pro.', 'instagram-feed'),
					'inactiveFieldPlaceholder' => __('Paste license key here', 'instagram-feed'),
					'upgradeText1' => sprintf(__('You are using the Lite version of the plugin–no license needed. Enjoy! 🙂 To unlock more features, consider %s.', 'instagram-feed'), '<a href="' . $upgrade_url . '">' . __('upgrading to Pro.', 'instagram-feed') . '</a>'),
					'upgradeText2' => __('As a valued user of our Lite plugin, you receive 50% OFF - automatically applied at checkout!', 'instagram-feed'),
					'manageLicense' => __('Manage License', 'instagram-feed'),
					'test' => __('Test Connection', 'instagram-feed'),
					'recheckLicense' => __('Recheck license', 'instagram-feed'),
					'licenseValid' => __('License valid', 'instagram-feed'),
					'licenseExpired' => __('License expired', 'instagram-feed'),
					'connectionSuccessful' => __('Connection successful', 'instagram-feed'),
					'connectionFailed' => __('Connection failed', 'instagram-feed'),
					'viewError' => __('View error', 'instagram-feed'),
					'upgrade' => __('Upgrade', 'instagram-feed'),
					'deactivate' => __('Deactivate', 'instagram-feed'),
					'activate' => __('Activate', 'instagram-feed'),
				),
				'manageSource' => array(
					'title' => __('Manage Sources', 'instagram-feed'),
					'description' => __('Add or remove connected Instagram accounts', 'instagram-feed'),
				),
				'aiAgents' => array(
					'title' => __('AI Agents', 'instagram-feed'),
					'appsLabel' => __('Works with ChatGPT, Cursor and Claude', 'instagram-feed'),
					// "Do more with AI on Pro" strip under the MCP Write Access box (AgDR-9006).
					// Free edition only: an empty array in Pro, which the Vue v-if hides.
					'proUpsell' => $this->get_ai_pro_upsell(),
					'status' => $wpvibe['status'],
					'basename' => $wpvibe['basename'],
					'installDownloadUrl' => 'https://downloads.wordpress.org/plugin/vibe-ai.zip',
					'adminUrl' => admin_url('admin.php?page=vibe-ai'),
					'states' => array(
						'not_installed' => array(
							'heading' => __('Use Instagram Feed with Claude, ChatGPT and more.', 'instagram-feed'),
							'description' => $wpvibe_description,
							'button' => __('Install WPVibe for free', 'instagram-feed'),
						),
						'inactive' => array(
							'heading' => __('Use Instagram Feed with Claude, ChatGPT and more.', 'instagram-feed'),
							'description' => $wpvibe_description,
							'button' => __('Activate WPVibe', 'instagram-feed'),
						),
						'active' => array(
							'heading' => __('WPVibe is connected to Instagram Feed.', 'instagram-feed'),
							'description' => wp_kses(
								__('Manage Instagram Feed from your favorite AI agent.<br>Connect Claude, ChatGPT, Cursor or any MCP client in WPVibe.', 'instagram-feed'), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
								$ai_agents_allowed_html
							),
							'button' => __('Open WPVibe', 'instagram-feed'),
						),
						'installFailed' => array(
							'heading' => __('Use Instagram Feed with Claude, ChatGPT and more.', 'instagram-feed'),
							'description' => $wpvibe_description,
							'button' => __('Try again', 'instagram-feed'),
							/* translators: %s: URL to the Plugins screen */
							'error' => wp_kses(
								sprintf(__('Couldn\'t install WPVibe. <a href="%s">Install it from the Plugins screen</a> instead.', 'instagram-feed'), esc_url(admin_url('plugins.php'))), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
								$ai_agents_allowed_html
							),
						),
					),
				),
				'mcpWrite' => array(
					'title' => __('MCP Write Access', 'instagram-feed'),
					'helpText' => __('This will allow your AI agent to make changes to Instagram Feed.', 'instagram-feed'), // phpcs:ignore Generic.Files.LineLength.TooLong -- single literal for make-pot
				),
				'preserveBox' => array(
					'title' => __('Preserve settings if plugin is removed', 'instagram-feed'),
					'description' => __('This will make sure that all of your feeds and settings are still saved even if the plugin is uninstalled', 'instagram-feed'),
				),
				'importBox' => array(
					'title' => __('Import Feed Settings', 'instagram-feed'),
					'description' => __('You will need a JSON file previously exported from the Instagram Feed Plugin', 'instagram-feed'),
					'button' => __('Import', 'instagram-feed'),
				),
				'exportBox' => array(
					'title' => __('Export Feed Settings', 'instagram-feed'),
					'description' => __('Export settings for one or more of your feeds', 'instagram-feed'),
					'button' => __('Export', 'instagram-feed'),
				)
			),
			'feedsTab' => array(
				'localizationBox' => array(
					'title' => __('Localization', 'instagram-feed'),
					'tooltip' => '<p>This controls the language of any predefined text strings provided by Instagram. For example, the descriptive text that accompanies some timeline posts (eg: Smash Balloon created an event) and the text in the \'Like Box\' widget. To find out how to translate the other text in the plugin see <a href="https://smashballoon.com/sbi-how-does-the-plugin-handle-text-and-language-translation/?utm_campaign=instagram-free&utm_source=settings&utm_medium=docs">this FAQ</a>.</p>'
				),
				'timezoneBox' => array(
					'title' => __('Timezone', 'instagram-feed')
				),
				'cachingBox' => array(
					'title' => __('Caching', 'instagram-feed'),
					'pageLoads' => __('When the Page loads', 'instagram-feed'),
					'inTheBackground' => __('In the Background', 'instagram-feed'),
					'inTheBackgroundOptions' => array(
						'30mins' => __('Every 30 minutes', 'instagram-feed'),
						'1hour' => __('Every hour', 'instagram-feed'),
						'12hours' => __('Every 12 hours', 'instagram-feed'),
						'24hours' => __('Every 24 hours', 'instagram-feed'),
					),
					'am' => __('AM', 'instagram-feed'),
					'pm' => __('PM', 'instagram-feed'),
					'clearCache' => __('Clear All Caches', 'instagram-feed'),
					'cronTimeLabel' => __('Caching update time', 'instagram-feed'),
					'cronAmPmLabel' => __('Caching update time AM/PM', 'instagram-feed')
				),
				'gdprBox' => array(
					'title' => __('GDPR', 'instagram-feed'),
					'gdprTooltipFeatureInfo' => array(
						'headline' => __('Features that would be disabled or limited include: ', 'instagram-feed'),
						'features' => array(
							__('Only local images (not from Instagram\'s CDN) will be displayed in the feed.', 'instagram-feed'),
							__('Placeholder blank images will be displayed until images are available.', 'instagram-feed'),
							__('Video posts will link to the post on Instagram.com for visitors to watch.', 'instagram-feed'),
							__('Carousel posts will only show the first image in the lightbox.', 'instagram-feed'),
							__('The maximum image resolution will be 640 pixels wide in the lightbox.', 'instagram-feed'),
						)
					),
					'automatic' => __('Automatic', 'instagram-feed'),
					'yes' => __('Yes', 'instagram-feed'),
					'no' => __('No', 'instagram-feed'),
					'infoAuto' => $this->get_gdpr_auto_info(),
					'infoYes' => __('No requests will be made to third-party websites. To accommodate this, some features of the plugin will be limited.', 'instagram-feed'),
					'infoNo' => __('The plugin will function as normal and load images and videos directly from Instagram', 'instagram-feed'),
					'someInstagram' => __('Some Instagram Feed features will be limited for visitors to ensure GDPR compliance, until they give consent.', 'instagram-feed'),
					'whatLimited' => __('What will be limited?', 'instagram-feed'),
					'tooltip' => '<p><b>If set to “Yes”,</b> it prevents all images and videos from being loaded directly from Instagram’s servers (CDN) to prevent any requests to external websites in your browser. To accommodate this, some features of your plugin will be disabled or limited. </p>
                    <p><b>If set to “No”,</b> the plugin will still make some requests to load and display images and videos directly from Instagram.</p>
                    <p><b>If set to “Automatic”,</b> it will only load images and videos directly from Instagram if consent has been given by one of these integrated GDPR cookie Plugins.</p>
                    <p><a href="https://smashballoon.com/doc/instagram-feed-gdpr-compliance/?instagram&utm_campaign=instagram-free&utm_source=settings&utm_medium=docs" target="_blank" rel="noopener">Learn More</a></p>',
				),
				'wpconsentBox' => array(
					'title' => __('Install WPConsent for GDPR', 'instagram-feed'),
					'description' => __('Manage cookie and privacy preference features from a single place.', 'instagram-feed'),
					'description2' => __('Smash Balloon plugins work great with WPConsent.', 'instagram-feed'),
					'buttonText' => __('Install WPConsent', 'instagram-feed'),
					'installUrl' => 'https://wordpress.org/plugins/wpconsent-cookies-banner-privacy-suite/'
				),
				'customCSSBox' => array(
					'title' => __('Custom CSS', 'instagram-feed'),
					'placeholder' => __('Enter any custom CSS here', 'instagram-feed'),
				),
				'customJSBox' => array(
					'title' => __('Custom JS', 'instagram-feed'),
					'placeholder' => __('Enter any custom JS here', 'instagram-feed'),
				)
			),
			'advancedTab' => array(
				'legacyCSSBox' => array(
					'title' => __('Use legacy CSS', 'instagram-feed'),
					'helpText' => __('This would revert your CSS file for the feed to the file used in version 6.2. Enable this setting if your customizations are not working properly. ', 'instagram-feed') . '<a target="_blank" rel="noopener" href="https://smashballoon.com/doc/instagram-css-layout-changes/?utm_source=instagram-pro&utm_medium=settings-advanced&utm_campaign=63changes&utm_content=LearnMore">' . __('Learn More', 'instagram-feed') . '</a>',
				),
				'optimizeBox' => array(
					'header' => __('Image Optimization (Recommended)', 'instagram-feed'),
					'helpText' => __('Creates multiple local copies of image in different sizes and uses smallest size based on where it is displayed. ', 'instagram-feed') . '<strong>' . __('Uses local WordPress storage.', 'instagram-feed') . '</strong>',
					'reset' => __('Reset Image Storage', 'instagram-feed'),
					'title' => __('Use dynamic sizes', 'instagram-feed'),
					'formatTitle' => __('Default Image Format', 'instagram-feed'),
					'formats' => array(
						'webp' => __('WebP', 'instagram-feed'),
						'jpg' => __('JPG', 'instagram-feed'),
					),
				),
				'usageBox' => array(
					'title' => __('Usage Tracking', 'instagram-feed'),
					'helpText' => sprintf( __( 'Send a weekly report to Smash Balloon to help improve the product. No sensitive data is collected. You can disable this at any time. %s', 'instagram-feed' ), '<a href="' . $usage_tracking_url . '" target="_blank">' . __( 'Learn More', 'instagram-feed' ) . '</a>' ),
				),
				'resetErrorBox' => array(
					'title' => __('Reset Error Log', 'instagram-feed'),
					'helpText' => __('Clear all errors stored in the error log.', 'instagram-feed'),
					'reset' => __('Reset', 'instagram-feed'),
				),
				'ajaxBox' => array(
					'title' => __('AJAX theme loading fix', 'instagram-feed'),
					'helpText' => __('Fixes issues caused by Ajax loading themes. It can also be used to work around JavaScript errors on the page.', 'instagram-feed'),
				),
				'ajaxInitial' => array(
					'title' => __('Load Initial Posts with AJAX', 'instagram-feed'),
					'helpText' => __('Initial posts will be loaded using AJAX instead of added to the page directly. If you use page caching, this will allow the feed to update according to the "Check for new posts every" setting on the "Configure" tab.', 'instagram-feed'),
				),
				'enqueueHead' => array(
					'title' => __('Enqueue JavaScript in head', 'instagram-feed'),
					'helpText' => __('Add the JavaScript file for the plugin in the HTML "head" instead of the footer.', 'instagram-feed'),
				),
				'enqueueShortcode' => array(
					'title' => __('Enqueue CSS only on pages with the Feed', 'instagram-feed'),
					'helpText' => '',
				),
				'jsImages' => array(
					'title' => __('JavaScript Image Loading', 'instagram-feed'),
					'helpText' => __('Load images on the client side with JS, instead of server side.', 'instagram-feed'),
				),
				'loadAjax' => array(
					'title' => __('Fix a text shortening issue caused by some themes', 'instagram-feed'),
					'helpText' => __('Initial posts will be loaded using AJAX instead of added to the page directly. If you use page caching, this will allow the feed to update according to the "Check for new posts every" setting on the "Configure" tab.', 'instagram-feed'),
				),
				'adminErrorBox' => array(
					'title' => __('Admin Error Notice', 'instagram-feed'),
					'helpText' => __('This will disable or enable the feed error notice that displays in the bottom right corner of your site for logged-in admins.', 'instagram-feed'),
				),
				'feedIssueBox' => array(
					'title' => __('Feed Issue Email Reports', 'instagram-feed'),
					'helpText' => __('If the feed is down due to a critical issue, we will switch to a cached version and notify you based on these settings. <a href="' . $feed_issue_email_url . '" target="_blank">View Documentation</a>', 'instagram-feed'),
					'sendReport' => __('Send a report every', 'instagram-feed'),
					'to' => __('to', 'instagram-feed'),
					'placeholder' => __('Enter one or more email addresses separated by comma', 'instagram-feed'),
					'emailLabel' => __('Report recipient email addresses', 'instagram-feed'),
					'weekDays' => array(
						array(
							'val' => 'monday',
							'label' => __('Monday', 'instagram-feed')
						),
						array(
							'val' => 'tuesday',
							'label' => __('Tuesday', 'instagram-feed')
						),
						array(
							'val' => 'wednesday',
							'label' => __('Wednesday', 'instagram-feed')
						),
						array(
							'val' => 'thursday',
							'label' => __('Thursday', 'instagram-feed')
						),
						array(
							'val' => 'friday',
							'label' => __('Friday', 'instagram-feed')
						),
						array(
							'val' => 'saturday',
							'label' => __('Saturday', 'instagram-feed')
						),
						array(
							'val' => 'sunday',
							'label' => __('Sunday', 'instagram-feed')
						),
					)
				),
				'dpaClear' => array(
					'title' => __('Manage Data', 'instagram-feed'),
					'helpText' => __('Warning: Clicking this button will permanently delete all Instagram data, including all connected accounts, cached posts, and stored images.', 'instagram-feed'),
					'clear' => __('Delete all Platform Data', 'instagram-feed'),
				),
			),
			'debugTab'             => array(
				'dataSharingTitle'    => __( 'Data sharing', 'instagram-feed' ),
				'dataSharingDesc'     => __( 'We share limited, non-sensitive usage data to keep your plugins updated and improve our products. We never collect your feed content or your visitors’ personal information.', 'instagram-feed' ),
				'permissionsLinkText' => __( 'What permissions are being granted?', 'instagram-feed' ),
				'termsLinkText'       => __( 'Terms & Conditions', 'instagram-feed' ),
				'privacyLinkText'     => __( 'Privacy', 'instagram-feed' ),
				'permissionsUrl'      => $sbi_consent_permissions_url,
				'termsUrl'            => $sbi_consent_terms_url,
				'privacyUrl'          => $sbi_consent_privacy_url,
				'notificationsTitle'  => __( 'In-Plugin Notifications', 'instagram-feed' ),
				'notificationsDesc'   => __( 'We send you in-plugin notifications about updates, fixes, and new features.', 'instagram-feed' ),
				// When any Smash Balloon Pro plugin is active, consent is forced on
				// and governed centrally — the toggles are hidden on this tab.
				// See SBI_Consent::is_locked_by_pro().
				'lockedByPro'         => class_exists( 'SBI_Consent' ) && \SBI_Consent::is_locked_by_pro(),
			),
			'dialogBoxPopupScreen' => array(
				'deleteSource' => array(
					'heading' => __('Delete "#"?', 'instagram-feed'),
					'description' => __('This source is being used in a feed on your site. If you delete this source then new posts can no longer be retrieved for these feeds.', 'instagram-feed'),
				),
			),

			'selectSourceScreen' => SBI_Feed_Builder::select_source_screen_text(),
			'nextCheck' => $this->get_cron_next_check(),
			'loaderSVG' => '<svg version="1.1" id="loader-1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve" aria-hidden="true" focusable="false"><path fill="#fff" d="M43.935,25.145c0-10.318-8.364-18.683-18.683-18.683c-10.318,0-18.683,8.365-18.683,18.683h6.068c0-8.071,6.543-14.615,14.615-14.615c8.072,0,14.615,6.543,14.615,14.615H43.935z"><animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur="0.6s" repeatCount="indefinite"/></path></svg>',
			'checkmarkSVG' => '<svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" aria-hidden="true" focusable="false"><path class="checkmark__check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8"/></svg>',
			'timesCircleSVG' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" aria-hidden="true" focusable="false"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm0 448c-110.5 0-200-89.5-200-200S145.5 56 256 56s200 89.5 200 200-89.5 200-200 200zm101.8-262.2L295.6 256l62.2 62.2c4.7 4.7 4.7 12.3 0 17l-22.6 22.6c-4.7 4.7-12.3 4.7-17 0L256 295.6l-62.2 62.2c-4.7 4.7-12.3 4.7-17 0l-22.6-22.6c-4.7-4.7-4.7-12.3 0-17l62.2-62.2-62.2-62.2c-4.7-4.7-4.7-12.3 0-17l22.6-22.6c4.7-4.7 12.3-4.7 17 0l62.2 62.2 62.2-62.2c4.7-4.7 12.3-4.7 17 0l22.6 22.6c4.7 4.7 4.7 12.3 0 17z"/></svg>',
			'uploadSVG' => '<svg class="btn-icon" width="12" height="15" viewBox="0 0 12 15" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
			<path d="M0.166748 14.6667H11.8334V13H0.166748V14.6667ZM0.166748 6.33333H3.50008V11.3333H8.50008V6.33333H11.8334L6.00008 0.5L0.166748 6.33333Z" fill="#141B38"/></svg>',
			'checkmarCircleSVG' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" aria-hidden="true" focusable="false"><!-- Font Awesome Pro 5.15.4 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) --><path d="M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"/></svg>',
			'exportSVG' => '<svg class="btn-icon" width="12" height="15" viewBox="0 0 12 15" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
			<path d="M0.166748 14.6667H11.8334V13H0.166748V14.6667ZM11.8334 5.5H8.50008V0.5H3.50008V5.5H0.166748L6.00008 11.3333L11.8334 5.5Z" fill="#141B38"/></svg>',
			'reloadSVG' => '<svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
			<path d="M15.8335 3.66667L12.5002 7H15.0002C15.0002 8.32608 14.4734 9.59785 13.5357 10.5355C12.598 11.4732 11.3262 12 10.0002 12C9.16683 12 8.3585 11.7917 7.66683 11.4167L6.45016 12.6333C7.51107 13.3085 8.74261 13.667 10.0002 13.6667C11.7683 13.6667 13.464 12.9643 14.7142 11.714C15.9644 10.4638 16.6668 8.76811 16.6668 7H19.1668L15.8335 3.66667ZM5.00016 7C5.00016 5.67392 5.52695 4.40215 6.46463 3.46447C7.40231 2.52678 8.67408 2 10.0002 2C10.8335 2 11.6418 2.20833 12.3335 2.58333L13.5502 1.36667C12.4893 0.691461 11.2577 0.332984 10.0002 0.333334C8.23205 0.333334 6.53636 1.03571 5.28612 2.28596C6.03587 3.5362 3.3335 5.23189 3.3335 7H0.833496L4.16683 10.3333L7.50016 7" fill="#141B38"/></svg>',
			'tooltipHelpSvg' => '<svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path d="M9.1665 8H10.8332V6.33333H9.1665V8ZM9.99984 17.1667C6.32484 17.1667 3.33317 14.175 3.33317 10.5C3.33317 6.825 6.32484 3.83333 9.99984 3.83333C13.6748 3.83333 16.6665 6.825 16.6665 10.5C16.6665 14.175 13.6748 17.1667 9.99984 17.1667ZM9.99984 2.16666C8.90549 2.16666 7.82186 2.38221 6.81081 2.801C5.79976 3.21979 4.8811 3.83362 4.10728 4.60744C2.54448 6.17024 1.6665 8.28986 1.6665 10.5C1.6665 12.7101 2.54448 14.8298 4.10728 16.3926C4.8811 17.1664 5.79976 17.7802 6.81081 18.199C7.82186 18.6178 8.90549 18.8333 9.99984 18.8333C12.21 18.8333 14.3296 17.9554 15.8924 16.3926C17.4552 14.8298 18.3332 12.7101 18.3332 10.5C18.3332 9.40565 18.1176 8.32202 17.6988 7.31097C17.28 6.29992 16.6662 5.38126 15.8924 4.60744C15.1186 3.83362 14.1999 3.21979 13.1889 2.801C12.1778 2.38221 11.0942 2.16666 9.99984 2.16666ZM9.1665 14.6667H10.8332V9.66666H9.1665V14.6667Z" fill="#434960"/></svg>',
			'resetSVG' => '<svg width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path d="M12.668 3.33317L10.0013 5.99984H12.0013C12.0013 7.0607 11.5799 8.07812 10.8297 8.82826C10.0796 9.57841 9.06217 9.99984 8.0013 9.99984C7.33463 9.99984 6.68797 9.83317 6.13463 9.53317L5.1613 10.5065C6.01003 11.0467 6.99526 11.3335 8.0013 11.3332C9.41579 11.3332 10.7723 10.7713 11.7725 9.77107C12.7727 8.77088 13.3346 7.41432 13.3346 5.99984H15.3346L12.668 3.33317ZM4.0013 5.99984C4.0013 4.93897 4.42273 3.92156 5.17287 3.17141C5.92302 2.42126 6.94044 1.99984 8.0013 1.99984C8.66797 1.99984 9.31464 2.1665 9.86797 2.4665L10.8413 1.49317C9.99257 0.953006 9.00734 0.666224 8.0013 0.666504C6.58681 0.666504 5.23026 1.22841 4.23007 2.2286C3.22987 3.2288 2.66797 4.58535 2.66797 5.99984H0.667969L3.33464 8.6665L6.0013 5.99984" fill="#141B38"/></svg>'
		);

		$newly_retrieved_source_connection_data = SBI_Source::maybe_source_connection_data();
		if ($newly_retrieved_source_connection_data) {
			$sbi_settings['newSourceData'] = $newly_retrieved_source_connection_data;
		}

		if (isset($_GET['manualsource']) && $_GET['manualsource'] == true) {
			$sbi_settings['manualSourcePopupInit'] = true;
		}

		wp_localize_script(
			'settings-app',
			'sbi_settings',
			$sbi_settings
		);
	}

	/**
	 * Resolve the MCP Write Access value to store for a Settings save.
	 *
	 * The page posts back the whole model it loaded, so a tab opened while the
	 * toggle was on would, on any later unrelated save, write `true` back over a
	 * toggle an admin has since turned off. The page therefore carries the value
	 * it loaded the toggle with (`sbi_ai_write_enabled_loaded`). Turning writes OFF
	 * is always honoured (so the gate epoch still records the revocation); turning
	 * them ON is accepted only when this page loaded the toggle OFF. A post with no
	 * loaded marker (a page rendered by an older version) can never enable writes.
	 *
	 * @param array $advanced Posted `advanced` model section.
	 * @param bool  $stored   Currently stored value.
	 * @return bool
	 */
	private function reconcile_ai_write_toggle(array $advanced, $stored)
	{
		$posted = !empty($advanced['sbi_ai_write_enabled']);
		if (!$posted) {
			return false;
		}
		$loaded_off = array_key_exists('sbi_ai_write_enabled_loaded', $advanced) && empty($advanced['sbi_ai_write_enabled_loaded']);
		return $loaded_off ? true : (bool) $stored;
	}

	/**
	 * The Settings Data
	 *
	 * @return array
	 * @since 6.0
	 */
	public function get_settings_data()
	{
		$sbi_settings = wp_parse_args(get_option('sb_instagram_settings'), $this->default_settings_options());
		$sbi_cache_cron_interval = $sbi_settings['sbi_cache_cron_interval'];
		$sbi_cache_cron_time = $sbi_settings['sbi_cache_cron_time'];
		$sbi_cache_cron_am_pm = $sbi_settings['sbi_cache_cron_am_pm'];
		$sbi_ajax = $sbi_settings['sb_instagram_ajax_theme'];
		$active_gdpr_plugin = SB_Instagram_GDPR_Integrations::gdpr_plugins_active();
		$sbi_preserve_setitngs = $sbi_settings['sb_instagram_preserve_settings'];
		$custom_css = '';
		$custom_js = '';

		if (current_user_can('unfiltered_html')) {
			$custom_css = isset($sbi_settings['sb_instagram_custom_css']) ? wp_strip_all_tags(stripslashes($sbi_settings['sb_instagram_custom_css'])) : '';
			$custom_js = isset($sbi_settings['sb_instagram_custom_js']) ? stripslashes($sbi_settings['sb_instagram_custom_js']) : '';
		}

		// Check WPConsent plugin status.
		$wpconsent_file = 'wpconsent-cookies-banner-privacy-suite/wpconsent.php';
		$is_wpconsent_installed = file_exists(WP_PLUGIN_DIR . '/' . $wpconsent_file);
		$is_wpconsent_active = is_plugin_active($wpconsent_file);

		// Seed Debug-tab toggles from the central consent flags. These flags live in
		// top-level options (sbc_data_sharing_consent / sbc_in_plugin_notifications),
		// not inside sb_instagram_settings — see ConsentManager::update().
		$consent_flags = class_exists( 'SBI_Consent' )
			? \SBI_Consent::flags()
			: array_fill_keys( array( 'dsc', 'notif' ), (bool) 0 );

		return array(
			'general' => array(
				'preserveSettings' => $sbi_preserve_setitngs
			),
			'feeds' => array(
				'cachingType' => 'background',
				'cronInterval' => $sbi_cache_cron_interval,
				'cronTime' => $sbi_cache_cron_time,
				'cronAmPm' => $sbi_cache_cron_am_pm,
				'gdpr' => $sbi_settings['gdpr'],
				'gdprPlugin' => $active_gdpr_plugin,
				'customCSS' => $custom_css,
				'customJS' => $custom_js,
			),
			'wpconsentScreen' => array(
				'isPluginInstalled' => $is_wpconsent_installed,
				'isPluginActive' => $is_wpconsent_active,
				'installSVG' => SBI_Feed_Builder::builder_svg_icons('installPlugin'),
			),
			'advanced' => array(
				'sbi_enable_resize' => !$sbi_settings['sb_instagram_disable_resize'],
				'image_format' => $sbi_settings['image_format'],
				'usage_tracking' => SmashTrackingConfig::is_enabled(),
				'sbi_ajax' => $sbi_ajax,
				'sb_ajax_initial' => $sbi_settings['sb_ajax_initial'],
				'sbi_enqueue_js_in_head' => $sbi_settings['enqueue_js_in_head'],
				'sbi_enqueue_css_in_shortcode' => $sbi_settings['enqueue_css_in_shortcode'],
				'sbi_enable_js_image_loading' => !$sbi_settings['disable_js_image_loading'],
				'enqueue_legacy_css' => $sbi_settings['enqueue_legacy_css'],

				'enable_admin_notice' => !$sbi_settings['disable_admin_notice'],
				'enable_email_report' => $sbi_settings['enable_email_report'],
				'email_notification' => $sbi_settings['email_notification'],
				'email_notification_addresses' => $sbi_settings['email_notification_addresses'],
				'sbi_ai_write_enabled' => !empty($sbi_settings['sb_instagram_ai_write_enabled']),
				// What this page load saw for MCP Write Access; posted back with the
				// rest of the model so the save handler can tell a real flip from a stale tab.
				'sbi_ai_write_enabled_loaded' => !empty($sbi_settings['sb_instagram_ai_write_enabled']),
			),
			'debug'           => array(
				'sbc_data_sharing_consent'    => $consent_flags['dsc'],
				'sbc_in_plugin_notifications' => $consent_flags['notif'],
			),
		);
	}

	/**
	 * Return the default settings options for sbi_style_settings option
	 *
	 * @return array
	 * @since 6.0
	 */
	public function default_settings_options()
	{
		return sbi_defaults();
	}

	/**
	 * Get Links with UTM
	 *
	 * @return array
	 *
	 * @since 6.0
	 */
	public static function get_links_with_utm()
	{
		$license_key = null;
		if (get_option('sbi_license_key')) {
			$license_key = sanitize_key(get_option('sbi_license_key'));
		}
		$all_access_bundle_popup = sprintf('https://smashballoon.com/all-access/?license_key=%s&upgrade=true&utm_campaign=instagram-free&utm_source=balloon&utm_medium=all-access', $license_key);

		return array(
			'manageLicense' => 'https://smashballoon.com/account/downloads/?utm_campaign=instagram-free&utm_source=settings&utm_medium=manage-license',
			'popup' => array(
				'allAccessBundle' => $all_access_bundle_popup,
				'fbProfile' => 'https://www.instagram.com/SmashBalloon/',
				'twitterProfile' => 'https://twitter.com/smashballoon',
			),
		);
	}

	/**
	 * Data for the "Do more with AI on Pro" strip in the AI Agents card.
	 *
	 * Free edition only; returns an empty array in Pro. Features are picked by popup
	 * key (SBI_Pro_Upsell::BANNER_FEATURES) from the builder's own Pro-feature copy,
	 * so the strip never carries text of its own beyond the title and button label.
	 *
	 * @return array{title: string, features: string[], button: string, url: string}|array{}
	 */
	private function get_ai_pro_upsell()
	{
		if (!SBI_Pro_Upsell::is_free()) {
			return array();
		}
		$names = SBI_Pro_Upsell::banner_feature_names();
		return array(
			'title' => __('Do more with AI on Pro', 'instagram-feed'),
			'features' => $names,
			'button' => __('Upgrade to Pro', 'instagram-feed'),
			'newTab' => __('(opens in a new tab)', 'instagram-feed'),
			'url' => SBI_Pro_Upsell::upgrade_url('ai-agents-card', 'settings'),
		);
	}

	/**
	 * Get GDPR Automatic state information
	 *
	 * @return string $output
	 * @since 6.0
	 */
	public function get_gdpr_auto_info()
	{
		$gdpr_doc_url = 'https://smashballoon.com/doc/instagram-feed-gdpr-compliance/?instagram&utm_campaign=instagram-free&utm_source=settings&utm_medium=docs';
		$output = '';
		$active_gdpr_plugin = SB_Instagram_GDPR_Integrations::gdpr_plugins_active();
		if ($active_gdpr_plugin) {
			$output = $active_gdpr_plugin;
		} else {
			$output = sprintf(__('No GDPR consent plugin detected. Install a compatible GDPR consent %s, or manually enable the setting to display a GDPR compliant version of the feed to all visitors.', 'instagram-feed'), '<a href="' . esc_url($gdpr_doc_url) . '" target="_blank" rel="noopener">' . __('plugin', 'instagram-feed') . '</a>');
		}
		return $output;
	}

	/**
	 * Get Extensions License Information
	 *
	 * @return array
	 * @since 6.0
	 */
	public function get_extensions_license()
	{
		return;
	}

	/**
	 * Settings Page View Template
	 *
	 * @since 6.0
	 */
	public function global_settings()
	{
		SBI_View::render('settings.page');
	}

	/**
	 * Determine WPVibe's install/activation status.
	 *
	 * Scans the installed-plugins list for a plugin whose folder is
	 * `vibe-ai/`, rather than assuming a specific main-file name -- a
	 * plugin's wp.org slug and its main file are not guaranteed to match.
	 *
	 * @return array{status: string, basename: string|null} status is one
	 *               of 'not_installed' | 'inactive' | 'active'.
	 * @since 6.14.0
	 */
	private function get_wpvibe_status()
	{
		if (!function_exists('get_plugins')) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$wpvibe_basename = null;
		foreach (array_keys(get_plugins()) as $plugin_file) {
			if (strtok($plugin_file, '/') === 'vibe-ai') {
				$wpvibe_basename = $plugin_file;
				break;
			}
		}

		if (null === $wpvibe_basename) {
			return array(
				'status' => 'not_installed',
				'basename' => null,
			);
		}

		return array(
			'status' => is_plugin_active($wpvibe_basename) ? 'active' : 'inactive',
			'basename' => $wpvibe_basename,
		);
	}
}
